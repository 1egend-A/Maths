# 支撑材料说明（C 题　微网与外部电网电力调控策略）

本压缩包为论文《基于情景优化与滚动修正的微网购电调控策略》的支撑材料，
包含全部可运行源程序、自主产生的数据资料、五份正式 Excel 结果与较大篇幅中间结果。

## 一、目录与文件对应

| 文件或目录 | 内容 |
|---|---|
| `result1.xlsx` ~ `result4-3.xlsx`（在 `results/`） | 五份正式结果，按赛题模板工作表填写 |
| `code/Q1-Q4_solve.py` | 四问 LP 建模、滚动执行、风险实验与物理核验 |
| `code/Q1-Q4_build_assets.py` | 图表与 Excel 中间数据生成 |
| `code/Q1-Q4_export_workbooks.mjs` | 五份正式 Excel 结果导出 |
| `code/Q1-Q4_build_report.py` | 正文、公式与表格的 LaTeX 源文件生成 |
| `code/Q1-Q4_audit.py` | 独立终审：原始附件、守恒/SOC/费用、五份 Excel 反向核对 |
| `data/` | 统一时间口径后的实测、单日与小时预报 CSV |
| `results/` | 逐时段、逐日结果，五份 Excel 及审计 JSON |
| `report/report.tex` | 完整可编辑论文 LaTeX 源文件 |
| `report/figures/` | 论文图表（PDF / SVG / PNG 三种格式） |
| `source_inputs/` | 核查用原始附件 1--4 |

## 二、运行方法与顺序

在本包根目录依次执行：

```bash
python code/Q1-Q4_solve.py            # 1. 重建全部计算结果（写 results/）
python code/Q1-Q4_build_assets.py     # 2. 生成图表与 workbook_payload.json
python code/Q1-Q4_audit.py            # 3. 独立终审，全部应为 PASS
node   code/Q1-Q4_export_workbooks.mjs .   # 4. 导出五份正式 Excel
python code/Q1-Q4_build_report.py     # 5. 生成 report/report.tex
```

随后进入 `report/` 目录，连续两次执行 `xelatex` 编译论文 PDF（需两遍以正确解析交叉引用）。

### 环境

- Python 3.10+ ；依赖：`numpy` `pandas` `scipy` `matplotlib` `openpyxl`
- Node.js 18+ （仅第 4 步 Excel 导出需要）
- 论文编译需 `xelatex` 与 `ctex` 宏包

原始运行环境记录见 `results/environment.json`
（Python 3.12.14 / numpy 2.3.5 / scipy 1.17.0 / pandas 2.2.3 / matplotlib 3.10.8 / openpyxl 3.1.5）。
本包已在 Python 3.10.16 / numpy 2.2.0 / scipy 1.15.3 / matplotlib 3.9.3 下完整重跑通过。

## 三、已知限制（诚实说明）

1. **字体**：`report/fonts/` 内的 Noto Serif/Sans CJK 字体（40.98 MB）因超出支撑材料
   20 MB 体积上限而未随包分发。`Q1-Q4_build_assets.py` 在字体缺失时会自动回退到本机
   中文字体（优先 SimSun），**图表数据与版式不变，仅字形略有差异**。
   若需与论文插图逐字节一致，将 `NotoSerifCJKsc-Regular.otf` 放回
   `report/fonts/` 后重跑第 2 步即可（脚本会自动优先使用该字体）。
2. **`Q1-Q4_export_workbooks.mjs`** 依赖 `@oai/artifact-tool`（内部工具包，未必可公开安装）。
   五份正式 `result*.xlsx` 已随包提供，**请以随包的 Excel 文件为准**；
   `workbook_payload.json` 已一并给出，便于用其他工具重现同样内容。
3. **赛题提供的原始数据**（附件 1--5 完整件、题面 PDF、空白模板）除核查所需的
   附件 1--4 外未随包分发。
4. `q3_00` / `q3_0006` / `q3_0012` 三个消融实验仅保留逐日与审计结果
   （`_daily.csv` / `_audit.json`），未保留逐 10 分钟明细，以控制包体积。

## 四、可复现性核验

- `data_audit.json`：派生数据与原始附件的逐元素最大偏差全部为 `0.0`。
- `final_independent_audit.json`：五问在能量守恒、SOC 递推、费用重算、
  Excel 反向核对四项上均为 `PASS`（容差 1e-6）。
