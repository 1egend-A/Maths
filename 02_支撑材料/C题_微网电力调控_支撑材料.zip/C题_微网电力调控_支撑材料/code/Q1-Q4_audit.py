"""Independent final audit: source spreadsheets, physics, settlement, Excel exports."""
from pathlib import Path
import json
import numpy as np,pandas as pd
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data';S=ROOT/'source_inputs';O=ROOT/'results'
a=pd.read_csv(D/'actual_2025_10min.csv');b=pd.read_csv(D/'attachment1_10min.csv');fc=pd.read_csv(D/'forecast_hourly.csv')
report={}
arrays=[('single_day',pd.read_excel(S/'附件1(1).xlsx').iloc[:,1:].to_numpy(float),b[['price_yuan_per_kWh','load_kW','pv_forecast_kW']].to_numpy()),
 ('load',pd.read_excel(S/'附件2(1).xlsx',0).iloc[:,1:].to_numpy(float).ravel(),a.load_kW.to_numpy()),
 ('pv',pd.read_excel(S/'附件2(1).xlsx',1).iloc[:,1:].to_numpy(float).ravel(),a.pv_actual_kW.to_numpy()),
 ('price',pd.read_excel(S/'附件4(1).xlsx').iloc[:,1:].to_numpy(float).ravel(),a.price_yuan_per_kWh.to_numpy()),
 ('forecast',pd.read_excel(S/'附件3(1).xlsx').iloc[:,2:].to_numpy(float).ravel(),fc.pv_forecast_kW.to_numpy())]
report['raw_max_differences']={k:float(np.max(abs(x-y))) for k,x,y in arrays}
assert max(report['raw_max_differences'].values())==0
for name,book in [('q1','result1'),('q2','result2'),('q3','result3'),('q4_2','result4-2'),('q4_3','result4-3')]:
    f=pd.read_csv(O/f'{name}_dispatch.csv');one=name=='q1'
    p=b.price_yuan_per_kWh.to_numpy() if one or name in ['q2','q3'] else a.price_yuan_per_kWh.to_numpy().reshape(365,144)[31:].ravel()
    if not one and name in ['q2','q3']:p=np.tile(p,334)
    N=(b.load_kW-b.pv_forecast_kW).to_numpy()/6 if one else a.net_load_kW.to_numpy().reshape(365,144)[31:].ravel()/6
    e=np.zeros(144) if one else f.emergency.to_numpy();q=f.plan.to_numpy() if one else f.adjusted.to_numpy()
    start=np.r_[6000.,f.soc.to_numpy()[:-1]];start[f.slot.to_numpy()==1]=6000.
    balance=np.max(abs(q+e+f.discharge-f.charge-f.curtail-N))
    soc=np.max(abs(f.soc-start-.9*f.charge+f.discharge/.9))
    cost=p*(np.minimum(f.plan,q)+.5*np.maximum(0,f.plan-q)+1.5*np.maximum(0,q-f.plan)+5*e)
    error=float(np.max(abs(cost-f.total_cost)))
    assert max(balance,soc,error)<1e-6
    assert f.soc.min()>=1200-1e-6 and f.soc.max()<=10800+1e-6
    assert ((f.charge>1e-6)&(f.discharge>1e-6)).sum()==0
    wb=load_workbook(O/(book+'.xlsx'),data_only=True)
    plan=list(wb['计划购电量'].values)
    if one:
        grid=np.array([r[1] for r in plan[1:]],float)
        assert plan[1][0]=='00:00-00:10' and plan[-1][0]=='23:50-24:00'
    else:
        assert len(plan)==335 and plan[0][1]=='00:00-00:10' and plan[0][144]=='23:50-24:00'
        dates=[pd.Timestamp(r[0]).strftime('%Y-%m-%d') for r in plan[1:]]
        assert dates==list(f.date.unique())
        grid=np.array([r[1:145] for r in plan[1:]],float).ravel()
        assert np.max(abs(np.array([r[145] for r in plan[1:]])-f.groupby('date').plan.sum().to_numpy()))<1e-6
        assert np.max(abs(np.array([r[146] for r in plan[1:]])-f.groupby('date').plan_cost.sum().to_numpy()))<1e-6
        if name in ['q3','q4_3']:
            rr=list(wb['调整购电量'].values)[1:]
            assert np.max(abs(np.array([r[1:145] for r in rr],float).ravel()-q))<1e-6
            assert np.max(abs(np.array([r[146] for r in rr])-f.groupby('date').total_cost.sum().to_numpy()))<1e-6
        battery=list(wb['充放电量'].values)[1:];assert len(battery)==334*6
        ch=np.array([r[2] for r in battery],float);dis=np.array([r[3] for r in battery],float)
        assert np.max(abs(ch-f.charge.to_numpy().reshape(-1,24).sum(1)))<1e-6
        assert np.max(abs(dis-f.discharge.to_numpy().reshape(-1,24).sum(1)))<1e-6
        em=pd.DataFrame(list(wb['紧急购电量'].values)[1:],columns=['date','interval','energy'])
        em.date=em.date.ffill().map(lambda v:pd.Timestamp(v).strftime('%Y-%m-%d'))
        sums=em.groupby('date').energy.sum().reindex(f.date.unique()).to_numpy(float)
        assert np.max(abs(sums-f.groupby('date').emergency.sum().to_numpy()))<1e-6
    ex=float(np.max(abs(grid-f.plan.to_numpy())));assert ex<1e-6
    report[name]={'slots':len(f),'max_energy_balance_error':float(balance),'max_soc_error':float(soc),
        'max_cost_error':error,'max_excel_plan_difference':ex,'total_cost':float(f.total_cost.sum()),'status':'PASS'}
(O/'final_independent_audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
