from pathlib import Path
import json,sys
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results';REP=ROOT/'report'
FIG=REP/'figures';FIG.mkdir(exist_ok=True)
font=REP/'fonts/NotoSerifCJKsc-Regular.otf'
if font.exists():
    font_manager.fontManager.addfont(str(font));_FAMILY=font_manager.FontProperties(fname=str(font)).get_name()
else:
    # 字体因体积原因未随支撑材料分发；回退本机中文字体，版式不变、字形可能略有差异。
    _have={f.name for f in font_manager.fontManager.ttflist}
    _FAMILY=next((c for c in ['Noto Serif CJK SC','Source Han Serif SC','SimSun','STSong','Microsoft YaHei'] if c in _have),'sans-serif')
    print(f'[warn] report/fonts 未随包分发，回退字体: {_FAMILY}',flush=True)
plt.rcParams.update({'font.family':_FAMILY,
 'font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,
 'axes.grid':True,'grid.alpha':.18,'svg.fonttype':'none','savefig.bbox':'tight'})
COL=['#245B84','#D18435','#3C8171','#9C5268'];DATES=['2025-03-20','2025-06-21','2025-09-23','2025-12-21']
NAMES={'q2':'问题二','q3':'问题三','q4_2':'问题四-2','q4_3':'问题四-3'}
frames={n:pd.read_csv(OUT/f'{n}_dispatch.csv') for n in NAMES}
daily={n:pd.read_csv(OUT/f'{n}_daily.csv',index_col=0) for n in NAMES}
a=pd.read_csv(ROOT/'data/actual_2025_10min.csv');b=pd.read_csv(ROOT/'data/attachment1_10min.csv')
F=np.load(OUT/'forecasts.npz');L=a.load_kW.to_numpy().reshape(365,144);V=a.pv_actual_kW.to_numpy().reshape(365,144);P=a.price_yuan_per_kWh.to_numpy().reshape(365,144)
def save(fig,n):
    fig.tight_layout()
    for ext in ['pdf','svg','png']:fig.savefig(FIG/f'{n}.{ext}',dpi=160)
    plt.close(fig)

def segments(values):
    mask=np.asarray(values)>1e-7;res=[];i=0
    while i<len(mask):
        if not mask[i]:i+=1;continue
        j=i+1
        while j<len(mask) and mask[j]:j+=1
        def clock(t):return f'{t//6:02d}:{t%6*10:02d}'
        res.append([clock(i)+'-'+clock(j),float(np.asarray(values)[i:j].sum())]);i=j
    return res

def charts():
    days=pd.date_range('2025-01-01',periods=365)
    fig,ax=plt.subplots(2,1,figsize=(6.5,4.4),sharex=True)
    ax[0].plot(days,L.sum(1)/6/1000,label='负载',color=COL[0]);ax[0].plot(days,V.sum(1)/6/1000,label='光伏',color=COL[1]);ax[0].set_ylabel('日电量 / MWh');ax[0].legend(ncol=2)
    ax[1].plot(days,P.mean(1),color=COL[2]);ax[1].set_ylabel('日均电价 / (元/kWh)');ax[1].set_xlabel('2025年');save(fig,'annual_data')
    q=pd.read_csv(OUT/'q1_dispatch.csv');t=np.arange(144)/6
    fig,ax=plt.subplots(3,1,figsize=(6.5,5.4),sharex=True)
    ax[0].plot(t,b.load_kW/1000,label='负载',color=COL[0]);ax[0].plot(t,b.pv_forecast_kW/1000,label='光伏',color=COL[1]);ax[0].plot(t,q.plan*6/1000,label='购电',color=COL[2]);ax[0].set_ylabel('功率 / MW');ax[0].legend(ncol=3)
    ax[1].fill_between(t,q.charge*6/1000,color=COL[0],label='充电');ax[1].fill_between(t,-q.discharge*6/1000,color=COL[1],label='放电');ax[1].set_ylabel('功率 / MW');ax[1].legend(ncol=2)
    ax[2].plot(np.arange(145)/6,np.r_[6000,q.soc]/1000,color=COL[2]);ax[2].axhline(1.2,ls='--',c='gray');ax[2].axhline(10.8,ls='--',c='gray');ax[2].set_ylabel('储电量 / MWh');ax[2].set_xlabel('时刻 / h');save(fig,'q1_dispatch')
    fig,ax=plt.subplots(1,2,figsize=(6.5,3.0))
    for n,c in zip(NAMES,COL):
        m=daily[n].copy();m.index=pd.to_datetime(m.index);m=m.resample('MS').sum()
        ax[0].plot(m.index.month,m.total_cost/1e4,'o-',ms=3,label=NAMES[n],color=c)
        ax[1].plot(m.index.month,m.emergency/1e3,'o-',ms=3,label=NAMES[n],color=c)
    ax[0].set_ylabel('月费用 / 万元');ax[1].set_ylabel('紧急电量 / MWh')
    for aa in ax:aa.set_xlabel('月份');aa.set_xticks(range(2,13,2))
    ax[0].legend(fontsize=8);save(fig,'monthly_compare')
    fig,ax=plt.subplots(2,1,figsize=(6.5,4.7))
    for n,c in [('q2',COL[0]),('q3',COL[1])]:
        f=frames[n];v=f.emergency.to_numpy().reshape(334,144)
        ax[0].plot(t,v.mean(0)*6,label=NAMES[n],color=c)
    ax[0].set_ylabel('平均紧急功率 / kW');ax[0].set_xlabel('时刻 / h');ax[0].legend()
    obs=frames['q3'].copy();obs['adjust']=obs.adjusted-obs.plan
    hh=obs.groupby((obs.slot-1)//36)['adjust'].sum()/1000
    ax[1].bar(['00-06','06-12','12-18','18-24'],hh,color=COL);ax[1].set_ylabel('净调整电量 / MWh');ax[1].set_xlabel('日内执行窗口');save(fig,'emergency_adjust')
    names=['q3_00','q3_0006','q3_0012','q3'];labels=['仅0时','0、6时','0、12时','0、6、12、18时']
    vals=[json.loads((OUT/f'{n}_audit.json').read_text()) for n in names]
    fig,ax=plt.subplots(1,2,figsize=(6.5,3.1))
    ax[0].bar(range(4),[v['total_cost']/1e4 for v in vals],color=COL);ax[0].set_ylabel('总费用 / 万元')
    ax[1].bar(range(4),[v['total_emergency']/1000 for v in vals],color=COL);ax[1].set_ylabel('紧急电量 / MWh')
    for aa in ax:aa.set_xticks(range(4),labels,rotation=20,fontsize=8)
    save(fig,'ablation')
    fig,ax=plt.subplots(1,2,figsize=(6.5,3.1));ax[0].plot(t,P[31:].mean(0),label='实测均价',color=COL[0]);ax[0].fill_between(t,np.quantile(P[31:],.1,axis=0),np.quantile(P[31:],.9,axis=0),alpha=.2,color=COL[0],label='10%-90%范围');ax[0].plot(t,b.price_yuan_per_kWh,label='附件1',color=COL[1]);ax[0].set_xlabel('时刻 / h');ax[0].set_ylabel('电价 / (元/kWh)');ax[0].legend(fontsize=8)
    ax[1].scatter(F['price'][31:].mean(1),P[31:].mean(1),s=9,alpha=.5,c=COL[2]);ax[1].plot([.4,1.1],[.4,1.1],ls='--',color='gray');ax[1].set_xlabel('日前预测日均电价 / (元/kWh)');ax[1].set_ylabel('实测日均电价 / (元/kWh)');save(fig,'price')
    fig,ax=plt.subplots(2,1,figsize=(6.5,4.9),sharex=True)
    dat='2025-09-23';ix=265
    for n,c in [('q3',COL[0]),('q4_3',COL[1])]:
        f=frames[n].query('date==@dat');ax[0].plot(t,f.adjusted*6/1000,label=NAMES[n],color=c);ax[1].plot(t,f.soc/1000,label=NAMES[n],color=c)
    ax[0].set_ylabel('最终购电功率 / MW');ax[1].set_ylabel('储电量 / MWh');ax[1].set_xlabel('时刻 / h');ax[0].legend();save(fig,'q4_day')
    fig,ax=plt.subplots(1,2,figsize=(6.5,3.2))
    vals=[frames['q4_2'].query('date in @DATES')]+[pd.read_csv(OUT/f'q4_risk_{x}_dispatch.csv') for x in [.25,.5,.75,1.]]
    lam=[0,.25,.5,.75,1.]
    ax[0].plot(lam,[v.total_cost.sum()/1e4 for v in vals],'o-',color=COL[0]);ax[0].set_ylabel('四日总费用 / 万元')
    ax[1].plot(lam,[v.emergency.sum() for v in vals],'o-',color=COL[1]);ax[1].set_ylabel('四日紧急电量 / kWh')
    for aa in ax:aa.set_xlabel('风险权重 λ');aa.set_xticks(lam)
    save(fig,'risk')
    # Point predictions are reported in kW, not kWh.
    predL=F['load']*6;predV=F['pv']*6
    feat={'load_rmse':float(np.sqrt(np.mean((predL[31:]-L[31:])**2))),
      'load_mape':float(100*np.mean(np.abs(predL[31:]-L[31:])/L[31:])),
      'pv_rmse':float(np.sqrt(np.mean((predV[31:]-V[31:])**2))),
      'official00_rmse':float(np.sqrt(np.mean(((F['load'][31:]-F['net4'][31:,0])*6-V[31:])**2))),
      'price_rmse':float(np.sqrt(np.mean((F['price'][31:]-P[31:])**2))),
      'negative_net_slots':int((L<V).sum()),'nearzero_slots':int((P<.1).sum())}
    (OUT/'features.json').write_text(json.dumps(feat,indent=2));print(feat)

def spreadsheet_payload():
    # Template's labels are shifted one slot. Correct labels; do not shift values.
    labels=[f'{i//6:02d}:{i%6*10:02d}-{(i+1)//6:02d}:{(i+1)%6*10:02d}' for i in range(144)]
    payload={}
    q=pd.read_csv(OUT/'q1_dispatch.csv')
    payload['result1']={'计划购电量':[['时间段','购电量 (kWh)']]+[[labels[i],float(q.plan.iloc[i])] for i in range(144)],
      '充放电量':[['时间段','充电量 (kWh)','放电量 (kWh)','时刻','储电量 (kWh)']]+
      [[f'{i*4:02d}:00-{(i+1)*4:02d}:00',float(q.charge.iloc[i*24:(i+1)*24].sum()),float(q.discharge.iloc[i*24:(i+1)*24].sum()),['00:00','24:00',None,None,None,None][i],6000 if i<2 else None] for i in range(6)]}
    for n,f in frames.items():
        name={'q2':'result2','q3':'result3','q4_2':'result4-2','q4_3':'result4-3'}[n]
        ss={'计划购电量':[['日期/时间']+labels+['全天计划购电量 (kWh)','全天计划购电费 (元)']],
         '充放电量':[['日期','时间段','充电量 (kWh)','放电量 (kWh)','时刻','储电量 (kWh)']],
         '紧急购电量':[['日期','购电时间段','购电量 (kWh)']]}
        rolling=n in ['q3','q4_3']
        if rolling:ss['调整购电量']=[['日期/时间']+labels+['全天调整后购电量 (kWh)','全天总购电费 (元)']]
        for date,g in f.groupby('date',sort=True):
            ss['计划购电量'].append([date]+g.plan.tolist()+[float(g.plan.sum()),float(g.plan_cost.sum())])
            if rolling:ss['调整购电量'].append([date]+g.adjusted.tolist()+[float(g.adjusted.sum()),float(g.total_cost.sum())])
            for i in range(6):
                z=g.iloc[i*24:(i+1)*24]
                ss['充放电量'].append([date if i==0 else None,f'{i*4:02d}:00-{(i+1)*4:02d}:00',float(z.charge.sum()),float(z.discharge.sum()),'00:00' if i==0 else ('24:00' if i==1 else None),6000 if i<2 else None])
            seg=segments(g.emergency)
            if not seg:seg=[['无',0.]]
            for i,(period,val) in enumerate(seg):ss['紧急购电量'].append([date if i==0 else None,period,val])
        # Preserve the required sheet order.
        order=['计划购电量']+(['调整购电量'] if rolling else [])+['充放电量','紧急购电量']
        payload[name]={k:ss[k] for k in order}
    (OUT/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False))

if __name__=='__main__':charts();spreadsheet_payload()
