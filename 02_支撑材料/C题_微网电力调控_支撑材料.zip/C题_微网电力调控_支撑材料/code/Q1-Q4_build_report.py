"""Build the complete Chinese LaTeX report directly from verified CSV outputs."""
from pathlib import Path
import json,sys
import numpy as np,pandas as pd
import importlib.util as _ilu
_spec=_ilu.spec_from_file_location('build_assets',Path(__file__).resolve().with_name('Q1-Q4_build_assets.py'))
_b=_ilu.module_from_spec(_spec);_spec.loader.exec_module(_b)
segments,DATES,NAMES=_b.segments,_b.DATES,_b.NAMES
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'results';R=ROOT/'report'
F={n:pd.read_csv(O/f'{n}_dispatch.csv') for n in NAMES}
A={n:json.loads((O/f'{n}_audit.json').read_text()) for n in NAMES}
Q=pd.read_csv(O/'q1_dispatch.csv');Q1=json.loads((O/'q1_audit.json').read_text())
FE=json.loads((O/'features.json').read_text())
chunks=[]
def num(x):return f'{float(x):,.2f}'
def para(s):return s.strip()+'\n\n'
def section(s):return '\\section*{'+s+'}\n'
def sub(s):return '\\subsection*{'+s+'}\n'
def eq(s):return '\\begin{equation}\n'+s+'\n\\end{equation}\n'
def fig(name,caption,width='.96'):
    return '\\begin{center}\\includegraphics[width='+width+'\\linewidth]{figures/'+name+'.pdf}\\captionof{figure}{'+caption+'}\\end{center}\n'
def table(caption,heads,rows,spec=None,size='10'):
    spec=spec or 'l'+'r'*(len(heads)-1)
    txt='\\begin{center}\\captionof{table}{'+caption+'}\n{\\fontsize{'+size+'}{13}\\selectfont\\setlength{\\tabcolsep}{4pt}\n'
    txt+='\\begin{tabular*}{\\linewidth}{@{\\extracolsep{\\fill}}'+spec+'@{}}\\toprule\n'
    txt+=' & '.join(heads)+' \\\\ \\midrule\n'
    for row in rows:txt+=' & '.join(str(x) for x in row)+' \\\\ \n'
    return txt+'\\bottomrule\\end{tabular*}}\\end{center}\n'
def page(title,body):
    chunks.append(('\\clearpage\n' if chunks else '')+section(title)+body)
def purchase_tables(n):
    out=''
    for date in DATES:
        f=F[n].query('date==@date').reset_index(drop=True);periods=[60,72,84,96,108,120]
        rows=[]
        for ii in [0,3]:
            row=[]
            for k in periods[ii:ii+3]:row.extend([f'{k//6:02d}:00-{k//6:02d}:10',num(f.plan.iloc[k])])
            rows.append(row)
        rows.append(['全天计划量',num(f.plan.sum()),'计划电费',num(f.plan_cost.sum()),'总购电费',num(f.total_cost.sum())])
        out+=table(NAMES[n]+'：'+date+'指定时段计划购电量及日汇总（kWh、元）',['时间段','购电量','时间段','购电量','时间段','购电量'],rows,'lrlrlr')
    return out
def battery_tables(n):
    out=''
    for date in DATES:
        f=F[n].query('date==@date').reset_index(drop=True);rows=[]
        for i in [0,2,4]:
            row=[]
            for j in [i,i+1]:
                z=f.iloc[j*24:(j+1)*24]
                row.extend([f'{j*4:02d}:00-{(j+1)*4:02d}:00',num(z.charge.sum()),num(z.discharge.sum())])
            rows.append(row)
        rows.append(['00:00储电量',num(6000),'', '24:00储电量',num(f.soc.iloc[-1]),''])
        out+=table(NAMES[n]+'：'+date+'储能分时充放电量（kWh）',['时间段','充电量','放电量','时间段','充电量','放电量'],rows,'lrrlrr')
    return out
def emergency_table(n):
    ss=[segments(F[n].query('date==@date').emergency) for date in DATES]
    rows=[]
    for i in range(max(map(len,ss))):
        row=[]
        for seg in ss:row+=([seg[i][0],num(seg[i][1])] if i<len(seg) else ['',''])
        rows.append(row)
    rows.append(sum([['合计',num(F[n].query('date==@date').emergency.sum())] for date in DATES],[]))
    heads=sum([[date[5:].replace('-','月')+'日','电量'] for date in DATES],[])
    return table(NAMES[n]+'：四个指定日期的全部紧急购电连续时段（kWh）',heads,rows,'lrlrlrlr',size='8.5')
def day_summary(n):
    rows=[]
    for date in DATES:
        z=F[n].query('date==@date');rows.append([date,num(z.adjusted.sum()+z.emergency.sum()),num(z.total_cost.sum()),num(z.emergency.sum()),num(z.emergency_cost.sum())])
    return table(NAMES[n]+'：指定日的实际结算汇总',['日期','总购电量/kWh','总费用/元','紧急量/kWh','紧急费/元'],rows,size='9.5')

preamble=r'''\documentclass[12pt,a4paper]{article}
\usepackage[margin=25.0mm,top=25.5mm,bottom=23.5mm,footskip=12mm]{geometry}
\usepackage{fontspec,amsmath,amssymb,booktabs,array,longtable,graphicx,caption,float,fancyhdr,titlesec,hyperref,listings}
\setmainfont{NotoSerifCJKsc-Regular.otf}[Path=fonts/,BoldFont=NotoSerifCJKsc-Regular.otf,BoldFeatures={FakeBold=1.6}]
\setsansfont{NotoSansCJKsc-Regular.otf}[Path=fonts/,BoldFont=NotoSansCJKsc-Regular.otf,BoldFeatures={FakeBold=1.5}]
\setmonofont{DejaVu Sans Mono}[Scale=.82]
\XeTeXlinebreaklocale "zh"
\XeTeXlinebreakskip=0pt plus 1pt
\hypersetup{hidelinks,pdftitle={基于情景优化与滚动修正的微网购电调控策略},pdfauthor={}}
\pagestyle{fancy}\fancyhf{}\fancyfoot[C]{\small -\ \thepage\ -}\renewcommand{\headrulewidth}{0pt}
\titleformat{\section}{\centering\sffamily\fontsize{14}{21}\selectfont}{}{0pt}{}
\titleformat{\subsection}{\sffamily\fontsize{12}{18}\selectfont}{}{0pt}{}
\titlespacing*{\section}{0pt}{4pt}{10pt}\titlespacing*{\subsection}{0pt}{8pt}{3pt}
\captionsetup{font=small,labelfont=bf,labelsep=colon,skip=4pt}
\renewcommand{\tablename}{表}\renewcommand{\figurename}{图}
\setlength{\parindent}{24pt}\setlength{\parskip}{2pt}
\setlength{\abovedisplayskip}{7pt}\setlength{\belowdisplayskip}{7pt}
\setlength{\emergencystretch}{2em}\setlength{\textfloatsep}{8pt}
\renewcommand{\arraystretch}{1.13}
\AtBeginDocument{\fontsize{12}{17.8}\selectfont}
\lstset{basicstyle=\ttfamily\fontsize{9}{11.5}\selectfont,breaklines=true,frame=single,numbers=left,numberstyle=\tiny,columns=fullflexible,keepspaces=true,showstringspaces=false}
\begin{document}
'''

# 1. Title and abstract: closely follow C229's title / abstract / four-question prose.
abstract=para('微网通过光伏本地消纳和储能跨时段转移电量，协调小区用电需求与外网交易。针对负载、光伏以及电价的不确定性，本文从数据时间对齐出发，建立统一的储能物理模型，在确定性优化、日前情景优化、日内滚动调整和波动电价决策四个层次上研究购电策略，并给出完整的10分钟调度结果。')
abstract+=para('首先，核对四份原始附件与已有预处理文件，统一日期、时段和电量单位。全年实测数据共52560条，光伏小时预报共35040条，原始数值与预处理结果逐项一致。将每个整点光伏预报近似为其对应小时的平均功率，采用保持小时电量不变的阶梯法降尺度。1月用于历史初始化，2月至12月的334天用于正式策略输出，所有预测与情景只取决策时刻已经获得的信息。')
abstract+=para(r'对于问题1，以计划购电费最小为目标，建立包含供需平衡、储能递推、充放电功率上限和日首尾储电量相等约束的线性规划。求得全天购电量59482.70 kWh，购电费35126.95元；相比无储能方案减少购电费12925.10元，降幅为26.90\%。储能通过吸收光伏富余电量、低价充电和高价放电降低支出，日末储电量恢复至6000 kWh。')
abstract+=para('对于问题2，分别采用同星期负载组合预测和近7日光伏均值预测，以近30天的净负载预测残差构造情景，将计划电费与5倍紧急购电费联合最小化。给定充放电决策后，计划量具有0.8临界分位结构。334天计划电量为22099227.83 kWh，紧急电量为295713.07 kWh，总费用为14565425.45元。')
abstract+=para(r'对于问题3，引入每日四个时刻发布的光伏预报，在原0:00计划的基础上联合优化调整购电与剩余储能运行。明确采用取消电量退回原计划费、再按50\%支付违约费的结算口径，并将其写成分段线性目标。四次预报策略总费用为14603623.79元；相比仅使用0:00官方预报，节省330050.71元，紧急电量下降26.57\%。结果说明日内预报具有补救价值，但预测来源与更新频率的效果应分别评价。')
abstract+=para('对于问题4，实际电价仅用于执行结算，日前价格由历史数据预测，并以同一历史日期配对构造价格与净负载联合情景。重算问题2、3后，总费用分别为15398983.56元和15437919.30元。进一步以条件风险价值建立风险扩展，在指定四日开展风险权重实验，展示提前备量、紧急购电和总费用之间的权衡。')
abstract+=para('最后，通过逐时段守恒、SOC递推、费用分解、日边界以及线性规划原对偶间隙进行核验。四套全年策略均满足设备约束，数值误差处于计算容差内。本文的最优性结论针对所设情景子问题；后续问题中的每日6000 kWh末端政策属于保守建模选择，未来年度表现仍受预测误差与结算规则影响。')
chunks.append(section('基于情景优化与滚动修正的微网购电调控策略')+section('摘　要')+abstract+para(r'\textbf{关键词：} 微网调控；储能调度；情景线性规划；滚动优化；条件风险价值'))

# 2
page('一、问题重述',para('微网连接小区负载、分布式光伏与外网，并利用储能设备调节不同时段的供需。当光伏出力较高或外网电价较低时，电量可以存入储能；当负载上升或交易电价较高时，再释放储能减少购电。购电计划既要满足供电要求，也要考虑提前申报、预测偏差及日内调整带来的费用。')+
para('问题1：根据附件1给定的单日电价、负载和光伏预测，建立0:00制定全天计划的模型，要求储能在0:00与24:00电量相同。给出六个指定10分钟时段的购电量、全天电量和费用，以及六个4小时区间的充放电量，输出result1.xlsx。')+
para('问题2：固定每日价格曲线，使用附件2历史负载与光伏数据制定日前计划。缺电部分按交易时刻电价的5倍紧急购买，其他购电按计划结算。输出2月至12月的完整策略，并列明3月20日、6月21日、9月23日、12月21日的指定结果。')+
para('问题3：在问题2基础上，使用每日0:00、6:00、12:00和18:00发布的未来24小时光伏预报。0:00制定计划，其他时刻可调整未执行时段，调减和调增分别涉及0.5倍、1.5倍价格，分析额外预报时刻是否有必要。')+
para('问题4：将附件4中的波动电价纳入决策，重新计算问题2和问题3，形成result4-2.xlsx与result4-3.xlsx。需明确区分决策时可预测的价格与执行后实现的价格，避免利用未知未来信息。')+
section('二、问题分析')+
para(r'四问共享同一套设备约束，差别主要体现在信息来源、决策更新频率及费用函数。问题1可以直接建立确定性线性规划；问题2需要用历史误差描述未来净负载，并在正常购电与高价紧急购电之间权衡；问题3还需同时决定是否调整和如何调整储能运行；问题4则增加价格不确定性和价格与需求之间的相关性。')+
para('据此，本文依次进行数据预处理、构造统一物理约束、建立情景费用函数、逐日滚动求解，再用实际值结算。比较预报更新方案时固定预测来源和求解方法；比较价格机制时固定负载与光伏的处理方式。各方案统一统计计划费用、退款、调减违约费、调增费和紧急费，避免只比较其中一项而误判经济性。')+table('题目要求与正式结果文件对应',['任务','决策形式','结果文件'],[['问题1','单日确定性计划','result1.xlsx'],['问题2','历史预测的日前计划','result2.xlsx'],['问题3','光伏预报滚动更新','result3.xlsx'],['问题4','波动电价下的两套策略','result4-2.xlsx、result4-3.xlsx']],spec='lll'))

# 3
page('三、模型假设与符号说明',sub('3.1 模型假设')+
para('（1）各10分钟时段内功率以平均值表示，电价按该时段交易价格结算；不计线路损耗和储能自放电。负载必须满足，不考虑售电收益，富余电量允许弃用。')+
para('（2）充电效率和放电效率分别取0.90。储能容量为12000 kWh，运行电量限制在1200至10800 kWh，充放电功率均不超过5000 kW。所有充放电量均在交流侧计量。')+
para('（3）问题1日首尾均取6000 kWh。问题2至问题4也采用每日恢复6000 kWh的保守政策，以保证跨日状态一致；这是本文附加的调度政策，不是题目对后续三问的强制条件。1月采用不充不放的初始化运行，故2月1日初值为6000 kWh。')+
para(r'（4）调整针对尚未执行的时段，均相对当日0:00原计划结算。调减电量不再收取原计划费，而收取50\%违约费。此口径沿用项目基础章节；如果采用原计划费不退的合同，需改写目标后重新优化。')+
para('（5）后续时段的负载、光伏实测和电价实测均不提前可见。官方光伏预报以发布时间为界使用，参数不按正式输出区间的未来数据重新选择。')+
sub('3.2 主要符号')+
table('主要符号及计量口径',['符号','含义','单位'],[
['$d,t,s$','日期、日内时段、情景编号','-'],[r'$\Delta t$','调度时长，取$1/6$','h'],
['$L_{d,t},V_{d,t}$','负载电量、光伏电量','kWh'],['$N_{d,t}$','净负载电量，$L_{d,t}-V_{d,t}$','kWh'],
['$g_{d,t},a_{d,t}$','原计划购电量、调整后购电量','kWh'],['$e_{d,t},r_{d,t}$','紧急购电量、弃用电量','kWh'],
['$c_{d,t},b_{d,t}$','充电量、放电量','kWh'],['$S_{d,t}$','时段末储电量','kWh'],
['$p_{d,t},p^s_{d,t}$','实际电价、情景电价','元/kWh'],[r'$\hat N_{d,t},R_{j,t}$','净负载预测、历史预测残差','kWh'],
[r'$\eta_c,\eta_b$','充电效率、放电效率，均为0.9','-'],[r'$\lambda,\alpha$','风险权重、CVaR置信水平','-']],spec='lll')+
para('以下所有目标函数均以元为单位。除图中明确标注的功率曲线外，正文和结果表统一使用时段电量，以避免重复乘以或漏乘调度时长。'))

# 4
page('四、数据预处理',sub('4.1 原始附件核查')+
para(r'根据题目与项目资料\cite{problem,project}，附件1包含单日144个时段；附件2给出全年365天的负载与实测光伏；附件3包含每日四次发布、每次24个小时值的光伏预报；附件4提供全年实测电价。读取Excel后，按日期和时段合并，并与已有CSV预处理文件逐项比对。五组数值数组的最大差异均为0，未发现缺失数值和重复主键。')+
table('数据规模与观测范围',['数据项','记录或范围','作用'],[
['单日基础数据','144时段','问题1与固定电价'],['全年实测数据','52560时段','历史预测与执行评价'],['小时光伏预报','35040个值','问题3和问题4'],['负载功率','1995.7176至7978.8849 kW','保留原值'],['光伏功率','0至10216.2000 kW','保留夜间零值'],['实测电价','0.0076至1.7936元/kWh','保留近零价格']],spec='lll')+
fig('annual_data','全年负载、光伏日电量与日均价格。各点均由原始实测数据汇总。')+
para('全年共有10130个时段光伏电量超过负载。电价低于0.10元/kWh的时段有28个。净负载为负表示存在可储存或弃用的富余电量，不能直接将其截为零后再建立储能模型。近零电价属于原始观测，也不应通过平滑处理删除。'))

# 5
page('4.2 时间对齐与预报降尺度',para('实测附件中的时间标签采用右端点解释：00:10对应00:00至00:10，00:00+1对应当日23:50至次日00:00。输出模板原表头从00:10至00:20开始，末列延伸至次日00:10，与完整自然日错开一个时段。本文保留模板的工作表和字段结构，将表头改为00:00至00:10开始、23:50至24:00结束，电量仍按真实时段填写。')+
eq(r'L_{d,t}=P^L_{d,t}\Delta t,\qquad V_{d,t}=P^V_{d,t}\Delta t,\qquad N_{d,t}=L_{d,t}-V_{d,t}.')+
para(r'附件3的日期列含合并单元格，按日向下补齐日期标识，不插补预报数值。设发布时刻为$\tau$、预报序号为$k$，将第$k$个整点功率视为对应小时的平均功率，目标区间为')+
eq(r'I_{\tau,k}=[\tau+(k-1)\mathrm{h},\ \tau+k\mathrm{h}),\qquad k=1,\ldots,24.')+
table('不同发布时刻的预报区间示例',['发布时刻','预报序号','对应区间'],[
['当日00:00','1','当日00:00至01:00'],['当日00:00','24','当日23:00至24:00'],['当日06:00','1','当日06:00至07:00'],['当日06:00','19','次日00:00至01:00'],['当日18:00','24','次日17:00至18:00']],spec='lll')+
para('这是一项将点预报用于电量调度的离散化假设。小时平均近似与真实连续出力的差异由历史预测残差吸收。0:00发布的第24列对应本日最后一小时，不能再多平移一天。年末36条小时预报越出2025年的实测覆盖范围，仅保留原始记录，不参与误差评价。')+
para('主模型使用阶梯降尺度。若小时预报功率为$H_{d,h}$，则所属六个10分钟时段各取相同功率，其时段电量及守恒关系为')+
eq(r'\hat V_{d,6h+j}=\frac{H_{d,h}}6,\quad j=1,\ldots,6;\qquad \sum_{j=1}^{6}\hat V_{d,6h+j}=H_{d,h}\times1\mathrm{h}.')+
para('该方法无需全年实测曲线作为形状先验，可以直接用于因果回测。已有项目中的全年形状法仅能用于回溯比较，不能作为无未来信息的证据。若采用形状权重，应仅由决策时刻之前的数据估计，并保证每个小时的六段电量总和不变。本文正式结果均采用阶梯法。'))

# 6
page('五、统一的储能物理模型',sub('5.1 供需平衡与储能约束')+
para('记当前生效的外网申报电量为$q_{d,t}$。在日前不可调整场景中$q_{d,t}=g_{d,t}$，允许调整时$q_{d,t}=a_{d,t}$。将紧急购电和弃用电量分别置于供给端与需求端，有')+
eq(r'q_{d,t}+e_{d,t}+V_{d,t}+b_{d,t}=L_{d,t}+c_{d,t}+r_{d,t}.')+
para('弃用电量是未被负载和储能吸收的富余供给。若将它误写为额外供电项，模型便可能通过增加弃电来弥补缺电，这是不符合能量守恒的。储电量递推必须为等式：')+
eq(r'S_{d,t}=S_{d,t-1}+\eta_c c_{d,t}-\frac{b_{d,t}}{\eta_b}.')+
eq(r'1200\le S_{d,t}\le10800,\qquad 0\le c_{d,t},b_{d,t}\le\frac{5000}{6}.')+
eq(r'q_{d,t},e_{d,t},r_{d,t}\ge0,\qquad S_{d,0}=S_{d,144}=6000.')+
para('上述首尾等式在问题1中落实题设要求，在后续三问中定义统一的日末保守政策。1月的初始化轨迹为$c=b=0$、$S=6000$，由计划和紧急购电共同满足负载，因此2月初的状态由可行历史轨迹承接，无需凭空重置储电量。')+
sub('5.2 互斥充放电的处理')+
para(r'在允许免费弃用、无负电价的当前模型中，可构造不同时充放电且费用不增加的最优解。若某一时段$c>0,b>0$，取$\delta=\min(c,b/(\eta_c\eta_b))$，并替换为')+
eq(r'c^{\prime}=c-\delta,\qquad b^{\prime}=b-\eta_c\eta_b\delta.')+
para(r'替换后至少一项为零，SOC增量保持不变，净取电需求减少$(1-\eta_c\eta_b)\delta$。保持申报量不变即可减少紧急电量或增加弃用量，费用不会上升。因此无需引入整数变量也能构造互斥解。程序在求解后消除可能的退化充放电，再独立检查全部物理关系。这个结论依赖免费弃用等假设，不宜推广为所有储能模型的通用性质。')+sub('5.3 储能转移电量的经济条件')+para('若低价时段从外网买入1 kWh并经一次完整充放电循环，则最终可替代高价购电的电量为0.81 kWh。忽略其他约束时，只有高价时段节约金额超过低价买入成本，这次转移才有收益。')+eq(r'0.81p_{\rm high}>p_{\rm low},\qquad p_{\rm high}/p_{\rm low}>1/0.81\approx1.2346.')+para('这个条件只是跨时段转移的局部判断。光伏富余电量的机会成本、容量占用和后续供电风险，也会改变储能的最优用途。'))

# 7
qrows=[]
for inds in [[60,72,84],[96,108,120]]:
    row=[]
    for t in inds:row.extend([f'{t//6:02d}:00-{t//6:02d}:10',num(Q.plan.iloc[t])])
    qrows.append(row)
qrows.append(['全天购电量',num(Q.plan.sum()),'全天购电费',num(Q.total_cost.sum()),'',''])
brows=[]
for i in [0,2,4]:
    row=[]
    for j in [i,i+1]:
        z=Q.iloc[j*24:(j+1)*24];row.extend([f'{4*j:02d}:00-{4*j+4:02d}:00',num(z.charge.sum()),num(z.discharge.sum())])
    brows.append(row)
brows.append(['00:00储电量',num(6000),'','24:00储电量',num(6000),''])
page('六、模型建立与求解',sub('6.1 问题1：确定性计划购电')+
para('附件1给出全天144个时段的价格、负载和光伏预测，因此当天0:00可以一次性确定计划购电和储能充放电。以全天计划购电费用最小为目标：')+
eq(r'\min Z_1=\sum_{t=1}^{144}p_tg_t.')+
para(r'约束采用第五节的供需平衡与储能递推，并令$e_t=0$，即计划供给在预测情形下直接满足负载。储能末端恢复6000 kWh，避免把消耗初始储能误当作节约。求解器采用HiGHS线性规划算法\cite{highs,scipy}，最优目标值为35126.948589元。')+
table('问题1：指定时段购电量与全天结果（kWh、元）',['时间段','购电量','时间段','购电量','时间段','购电量'],qrows,'lrlrlr')+
table('问题1：指定时段储能充放电量（kWh）',['时间段','充电量','放电量','时间段','充电量','放电量'],brows,'lrrlrr')+
para('完整结果写入result1.xlsx的“计划购电量”和“充放电量”工作表。表中充电量与放电量均为交流侧电量，不能直接用二者之差代替SOC变化；必须分别乘以充电效率或除以放电效率。各指定10分钟时段由真实起止时间索引，不按错位模板列名取值。')+
para('由于部分相邻时段的价格差较小，最优调度可能存在等价时序。判定两个解是否一致，应先比较费用、能量守恒和设备约束；不能仅凭某一个10分钟时段的储能动作不同，就认定其中一个解有误。'))

# 8
page('6.1.1 问题1结果分析',fig('q1_dispatch','问题1的购电功率、充放电功率与储电量轨迹。放电在中图以下方区域表示。')+
para('从图中可见，储能的作用同时包括吸收光伏富余电量和转移外网购电时刻。光伏较强时，购电量可以降至零，剩余出力用于充电；外网价格较低时，即使光伏不足，也可能同时增加购电和充电；高价时段则释放储能，减少昂贵购电。')+
table('问题1与无储能基准的比较',['指标','无储能','优化方案','变化'],[
['全天购电量/kWh',num(Q1['baseline_purchase']),num(Q1['purchase']),num(Q1['purchase']-Q1['baseline_purchase'])],
['全天购电费/元',num(Q1['baseline_cost']),num(Q1['cost']),num(Q1['cost']-Q1['baseline_cost'])]],spec='lrrr')+
para(r'无储能基准仅使用光伏直接供电，并从外网购买正净负载。其费用为48052.05元，优化后减少12925.10元。此处购电量也下降约2307.24 kWh，说明新增的光伏消纳收益超过储能损耗。费用下降26.90\%包含电量减少与购电时序变化两方面，不能全部归因于电池效率。')+
para(r'原对偶目标间隙约为$7.28\times10^{-12}$元，SOC递推最大误差低于$10^{-9}$ kWh，说明该确定性线性规划已在数值精度内达到全局最优。'))

# 9
page('6.2 问题2：历史预测与情景构造',sub('6.2.1 决策信息与日前预测')+
para('问题2在0:00只能使用附件1固定电价，以及附件2中决策日前已经实现的负载、光伏。附件3的官方预报不进入本问。为保留小区用电的星期规律，采用上周同日与近四周同星期均值的组合；光伏采用近7日同时段均值。正式输出区间的预测式为')+
eq(r'\hat L_{d,t}=\frac12L_{d-7,t}+\frac18\sum_{i=1}^{4}L_{d-7i,t},\qquad \hat V_{d,t}=\frac17\sum_{i=1}^{7}V_{d-i,t}.')+
para('1月历史不足时，负载组合只使用已有同星期记录；尚无同星期数据时采用前一日。1月1日使用附件1作为初始化剖面。这些初期预测只用于形成历史误差和初始化记录，不以当天未知实测代替预测。')+
eq(r'\hat N_{d,t}=\hat L_{d,t}-\hat V_{d,t},\qquad R_{j,t}=N_{j,t}-\hat N_{j,t}.')+
para('对每个输出日，取此前30天的整日残差路径。各情景沿用同一历史日期的144个时段，保留误差在日内的时序关系；情景等概率，避免对每个时段独立打乱残差。')+
eq(r'N_{d,t}^{s}=\hat N_{d,t}+R_{d-s,t},\qquad s=1,\ldots,30.')+
table('2月至12月的预测误差评价',['对象','评价指标','计算值'],[
['负载','RMSE / kW',num(FE['load_rmse'])],['负载','MAPE',num(FE['load_mape'])+r'\%'],['自预测光伏','RMSE / kW',num(FE['pv_rmse'])],['0:00官方光伏阶梯预报','RMSE / kW',num(FE['official00_rmse'])]],spec='llr')+
para(r'以上指标均以正式输出区间的预测与实测逐点比较得到，且功率误差统一以kW报告。参数形式继承项目已有方法，此处指标用于描述该方法表现，没有再使用未来结果调参。负载组合预测MAPE为3.93\%，光伏自预测RMSE为303.86 kW。该指标的评估区间为2025年2月1日至12月31日共334天；官方0:00预报按阶梯方式降尺度到10分钟，再与该区间的实测逐点比较。')+
para('官方预报的0:00阶梯结果在本数据上的RMSE较大，表明增加一个预报来源并不自动提高预测精度。问题3仍需单独评价“预报更新”能否降低购电费用，不能仅以预测次数更多作为方法更优的依据。'))

# 10
page('6.2.2 两阶段情景线性规划',para('第一阶段在0:00确定$g_t,c_t,b_t,S_t$。第二阶段对每条情景以紧急电量$u_t^s$补足缺口，实际运行时采用已经确定的充放电计划，由当期紧急购电完成可靠供电。省略日期下标后，目标和情景约束为')+
eq(r'\min Z_2=\sum_t p_tg_t+\frac1M\sum_{s=1}^{M}\sum_t5p_tu_t^s,\qquad M=30,')+
eq(r'u_t^s\ge N_t^s+c_t-b_t-g_t,\qquad u_t^s\ge0.')+
para('再加入第五节的SOC等式、功率及容量边界。变量共$4T+MT=4896$个，其中$T=144$；144条SOC等式连接日内时段，4320条情景约束描述缺电补偿。富余电量对应上述不等式的松弛，可在执行阶段由守恒式恢复。')+
sub('6.2.3 临界分位及其适用条件')+
para(r'固定一组充放电决策，令$X_t=N_t+c_t-b_t$。计划购电量的单时段费用为$f_t(g)=p_tg+5p_t\mathbb E[(X_t-g)^+]$，在连续分布下有')+
eq(r'f_t^{\prime}(g)=p_t\{1-5\Pr(X_t>g)\}.')+
eq(r'F_{X_t}(g_t^*)=0.8,\qquad g_t^*=\max\{0,F_{X_t}^{-1}(0.8)\}.')+
para(r'对于30个等概率情景，按升序记$z_{(1)}\le\cdots\le z_{(30)}$，取$g^*=\max(0,z_{(24)})$。无截断且相关次序统计量不相等时，$[z_{(24)},z_{(25)}]$内都可为最优值，本文采用平台左端点。存在重复值或零购电边界时，用次梯度条件解释，不能强制要求每个时段恰好出现6个严格缺电情景。')+
para('分位公式是在给定充放电变量后成立的。充放电仍必须通过含全部情景的线性规划联合求解；不能先针对某一个平均负载安排电池，再声称逐点套分位公式就得到联合最优。问题3和问题4改变费用结构后，也必须相应修改联合目标。')+
eq(r'e_t=\max(0,N_t+c_t-b_t-g_t),\qquad r_t=\max(0,g_t+b_t-c_t-N_t).')+
para('上式只在当期实际值实现后用于执行结算，不反馈到当天0:00的计划求解。紧急购电按5倍价格计费，因此最优策略可能主动购买一定备量，但不会为了消除所有极端缺口而无限提高计划量。'))

# 11/12/13
page('6.2.4 问题2指定日期的购电结果',para('以下按题目表1的“时间段—购电量”成对结构，分别列出四个指定日期。六个10分钟时段为0:00制定的计划量。日汇总同时列示计划电费与包含紧急购电的总费用，以区分正常申报成本和实际结算支出。')+purchase_tables('q2')+day_summary('q2')+
para('同一日期的总购电量等于计划量加紧急量，不扣除未被利用的富余电量；原因是问题2按计划结算，即使部分计划电量最终弃用，仍需承担对应购电费用。数值由完整144时段求和后保留两位小数，不能用六个指定时段代替全天统计。'))
page('6.2.5 问题2指定日期的储能结果',para('以下按题目表2的左右配对格式，将最终充放电量汇总到六个4小时区间。两侧依次排列0至4、4至8、8至12、12至16、16至20、20至24时段，末行给出日初和日末储电量。')+battery_tables('q2')+
para('四日首尾均为6000.00 kWh，符合本文的日末政策。某个4小时区间内同时出现正的充电总量和放电总量，并不表示电池在同一个10分钟时段同时充放电；两种动作可以发生在该区间内不同的小时间段。互斥性需要回到完整10分钟轨迹检查。')+
para('不同日期的光伏和负载预测不同，因此相同价格曲线下也可能出现不同的充放电安排。判断是否值得从外网充电，应综合未来价格、储能效率、SOC边界和预测缺口；“低价就充满”不是普遍最优规则。'))
page('6.2.6 问题2指定日期的紧急购电',para('按题目表3并列列出四个日期的全部紧急购电连续区间，相邻且紧急电量为正的10分钟时段合并，跨越零紧急量的时段不合并。表中日期均为2025年，空白表示该日期没有更多连续区间。')+emergency_table('q2')+
para('连续区间的电量为其包含时段的电量总和。若价格在区间内变化，费用仍须逐10分钟时段计算，而不能简单用某一个时刻的价格乘以整段电量。完整的全年区间清单保存在结果工作表中。')+
table('问题2四日紧急购电的强度',['日期','连续段数','紧急时段数','紧急费占总费'],[[date,len(segments(F['q2'].query('date==@date').emergency)),int((F['q2'].query('date==@date').emergency>1e-7).sum()),num(100*F['q2'].query('date==@date').emergency_cost.sum()/F['q2'].query('date==@date').total_cost.sum())+r'\%'] for date in DATES])+
para('紧急购电量描述事先计划之外的补偿需求，不等于最终未满足负载。本文允许外网按题设价格无限量紧急补偿，因此加入紧急购电后每个时段都满足负载要求。实际工程若存在外网容量限制，还需增加供电上限和失负荷约束。'))

# 14
rows=[]
for n in NAMES:
    x=A[n];rows.append([NAMES[n],num(x['total_cost']/1e4),num(x['total_adjusted']/1000),num(x['total_emergency']/1000),num(x['total_emergency_cost']/1e4)])
page('6.2.7 全区间结果与费用构成',para('问题2在334天中的计划购电量为22099227.83 kWh，计划费用13468138.59元；紧急购电量295713.07 kWh，紧急费用1097286.86元；合计购电量22394940.90 kWh，总费用14565425.45元。总费用是全部时段的结算值之和，不是模型情景目标值的总和。')+
table('四种主方案在334天内的结果',['方案','总费用/万元','生效申报/MWh','紧急量/MWh','紧急费/万元'],rows,size='9.5')+
fig('monthly_compare','四种主方案的月费用和月紧急电量。跨电价制度的差异同时包含价格变化。')+
para('各月总费用受到天数、负载水平、光伏出力和价格结构共同影响，不能直接将最高费用月份认定为预测最差月份。紧急购电量与总费用也不必同向变化：多申报可以减少紧急量，却可能增加未利用电量和计划费。')+
para('第二问新求解与项目原MATLAB结果在全年购电量和费用上吻合，说明统一电量单位、线性规划矩阵和费用重算保持了一致性。后续两问因调整目标和电价信息结构作了实质修正，报告采用本次重算值，不再混用旧图表中的数值。'))

#15
page('6.3 问题3：含调整费用的滚动优化',sub('6.3.1 统一结算函数')+
para('每天0:00先确定原计划$g_t$。在6:00、12:00和18:00，根据当时已发布预报以及已经执行的储能状态，重新优化剩余时段。已执行时段不作修改，每个未执行时段的调整量相对原0:00计划计算，避免反复修改同一未来时段时重复收取违约费。')+
eq(r'\Phi(g,a;p)=p\min(g,a)+0.5p(g-a)^++1.5p(a-g)^+.')+
para('当$a<g$时，未取消部分$a$按正常价格结算，取消部分$g-a$按半价承担违约费用；当$a>g$时，原计划部分按正常价格，增加部分按1.5倍价格。由此可以化简为')+
eq(r'\Phi(g,a;p)=pa+\frac12p|a-g|=pg-\frac12p(g-a)^++1.5p(a-g)^+.')+
para('费用也可以展开为“原计划费－取消退款＋调减违约费＋调增购电费”。这两个写法等价，用于程序的独立费用核对。若合同不退原计划费，调减行为在免费弃用假设下通常缺少经济动机，因此不能将两种合同口径的数值混合比较。')+
sub('6.3.2 剩余时域联合模型')+
para(r'设当前时刻为$\tau$，剩余时段为$\mathcal T_\tau$，当前已实现的储电量为$S_\tau$。情景净负载由同一发布时刻的历史误差构造。引入$v_t\ge|a_t-g_t|$，得到线性规划：')+
eq(r'\min\sum_{t\in\mathcal T_\tau}p_t\left(a_t+\frac12v_t\right)+\frac1M\sum_s\sum_{t\in\mathcal T_\tau}5p_tu_t^s,')+
eq(r'v_t\ge a_t-g_t,\quad v_t\ge g_t-a_t,\quad u_t^s\ge N_t^s+c_t-b_t-a_t,\quad u_t^s\ge0.')+
para('模型同时优化申报量和储能运行，SOC以已经执行的状态为起点，以本日24:00的6000 kWh为终点。0:00子问题没有调整项，其模型与问题2相同但光伏预测来源不同。每次只执行至下一个预报时刻，再滚动重算。')+table('调整结算函数的代数示例：原计划100 kWh，电价为$p$',['生效电量','结算构成','结算费用'],[['80 kWh','80p+0.5p×20','90p'],['100 kWh','100p','100p'],['120 kWh','100p+1.5p×20','130p']],spec='lll')+para('该表仅用于说明合同计算，不是实验数据。调减20 kWh后仍需支付90p，而不是只按80p结算；同样，增加20 kWh后的费用为130p，不能将全部120 kWh都按1.5倍价格收取。'))

#16
page('6.3.3 调整分位、信息时点与执行顺序',para('给定充放电变量后，调整后的净需求记为$X_t$。在$a_t<g_t$一侧，申报电量的边际结算价格为$0.5p_t$；在$a_t>g_t$一侧，边际价格为$1.5p_t$。与紧急价格$5p_t$比较，有')+
eq(r'q_{\mathrm{down}}=1-\frac{0.5}{5}=0.9,\qquad q_{\mathrm{up}}=1-\frac{1.5}{5}=0.7.')+
eq(r'a_t^*=\begin{cases}F_{X_t}^{-1}(0.7),&g_t<F_{X_t}^{-1}(0.7),\\g_t,&F_{X_t}^{-1}(0.7)\le g_t\le F_{X_t}^{-1}(0.9),\\F_{X_t}^{-1}(0.9),&g_t>F_{X_t}^{-1}(0.9),\end{cases}')+
para('上述关系还需服从非负边界，离散情景下以次梯度解释。它给出不调整区间：原计划落在0.7与0.9分位之间时，维持原计划可以避免调整成本。但是，这一规则依然是以充放电决策给定为前提。本文直接求解包含调整费用的联合LP，不采用先忽略违约费安排电池、再单独覆盖分位数的近似做法。')+
table('滚动决策可见信息与执行范围',['时刻','新获得信息','可优化范围','本次执行'],[
['00:00','历史实测、00时光伏预报','全天144时段','00:00至06:00'],['06:00','06时预报、已执行SOC','第37至144时段','06:00至12:00'],['12:00','12时预报、已执行SOC','第73至144时段','12:00至18:00'],['18:00','18时预报、已执行SOC','第109至144时段','18:00至24:00']],spec='llll',size='9')+
para('在每个发布时刻，近30天同一发布时刻的净负载残差都已经实现，可以直接形成经验情景。负载仍使用当天0:00的历史组合预测，因此本方案没有进一步利用日内负载观测来更新未来负载。该限制是预测器设计选择，不能解释为“滚动调整对负载误差在原理上无能为力”。')+
para('这一算法属于滚动时域情景优化：每次求解的LP达到所设子问题最优，但0:00没有显式构造未来三次预报分支的完整情景树，因此不声称获得整个四阶段随机控制问题的全局最优。每个子问题的求解最优性与年度预测决策的最优性应分别说明。'))

#17/18/19
page('6.3.4 问题3指定日期的购电结果',para('以下表格的六个指定时段仍表示0:00形成的原计划，以满足题目对“计划购电量”的要求。总购电费使用最终生效调整量与紧急量结算。原计划费是费用分解的第一项，取消退款及调整费用会使总费用与原计划费不同。')+purchase_tables('q3')+day_summary('q3')+
para('完整原计划保存在result3.xlsx的“计划购电量”表，最终生效申报保存在“调整购电量”表。调整量表填写的是调整后的总电量$a_t$，不是差值$a_t-g_t$。读者可由两张表相减得到带符号调整量。'))
page('6.3.5 问题3指定日期的储能结果',para('每个预报时刻只重算剩余时域，已执行的电池行为保持不变。因此下表是各次执行窗口拼接后的真实充放电汇总，而不是直接摘取最后一次求解给出的整日计划。')+battery_tables('q3')+
para('在6:00、12:00和18:00，程序将上一阶段最后一个时段的SOC传入下一阶段。跨阶段衔接采用能量状态，而不是重新赋值6000 kWh。6000 kWh只出现在日初和日末，中间状态可以在1200至10800 kWh之间变化。')+
para('四小时汇总区间与六小时预报窗口并不完全重合，例如04:00至08:00的表格行同时包含两次滚动决策的执行段。因此应先形成完整10分钟轨迹，再按题目时间段汇总，不能直接把每次优化的充电总量填入表2。'))
page('6.3.6 问题3指定日期的紧急购电',para('下表列出加入所有预报更新后最终发生的紧急购电连续区间。其来源为对应时段实际净负载超过生效申报量与电池净放电供给的部分。')+emergency_table('q3')+
table('问题3四日的调整与紧急费用',['日期','取消退款/元','调减违约费/元','调增费/元','紧急费/元'],[[date]+[num(F['q3'].query('date==@date')[k].sum()) for k in ['refund','down_penalty','up_cost','emergency_cost']] for date in DATES],size='9')+
para('总费用重算使用原计划费减取消退款，再加调减违约费、调增费和紧急费。取消退款是负向收支项，不能把它当成另一笔正费用。每一个时段的紧急电量均在最终申报和最终储能动作确定后计算，避免使用调整前的缺口而重复购电。')+
para('从连续段比较看，滚动策略可以减少部分午后缺口，但并不保证每个日期的紧急购电量都比问题2低。官方预报误差和负载误差可能在特定日期叠加，临界分位也只控制经验情景下的边际权衡，并非实际误差的确定上界。'))

#20
arows=[]
for name,label in [('q3_00','仅00:00'),('q3_0006','00:00、06:00'),('q3_0012','00:00、12:00'),('q3','每日四时刻')]:
    v=json.loads((O/f'{name}_audit.json').read_text());arows.append([label,num(v['total_cost']),num(v['total_emergency']),num((14933674.49802549-v['total_cost'])/14933674.49802549*100)+r'\%'])
page('6.3.7 是否需要引入其他时刻的预报',para('为回答题目关于其他预报时刻的要求，固定0:00的官方预报、负载预测器、30日残差窗口和联合LP，只改变日内是否更新预报。所有方案使用同一334天实测结果结算，比较具有一致的输入和费用口径。')+
table('预报更新时间的控制变量比较',['预报时刻','总费用/元','紧急量/kWh','相对仅00时节约'],arows,size='9.5')+
fig('ablation','预报时刻消融结果。每个方案均由完整调度重新计算。')+
para(r'每日四次预报相比只使用00:00官方预报减少费用330050.71元，降幅2.21\%，紧急电量由317561.52 kWh降至233171.74 kWh，下降26.57\%。仅增加06时或12时预报也能降低本数据集的总费用，因此有必要利用日内预报进行更新。')+
para('本次比较中四次更新的总费用最低，但这不意味着每次更新对每个日期都必然有利。预测更准可能降低紧急费，同时仍产生调整费用；应以完整总费用作为最终判断标准。若预报本身或系统运维需要额外付费，还应将取得信息的成本计入比较。')+
para(r'问题3的全年费用比问题2高38198.34元，约0.26\%。这与“日内预报有价值”并不矛盾：前者更换了预报来源，后者在相同来源下只改变更新频率。由于0:00官方预报在当前样本中的误差较大，额外更新只能部分弥补初始计划的不利影响。'))

#21
page('6.4 问题4：波动电价下的购电策略',sub('6.4.1 电价信息与联合情景')+
para('附件4给出交易时刻实际价格，并未保证当天0:00已经知道全天实测价格。本文把未来价格视为不确定量，以最近7天同时段均值作为日前预测，实际价格只在执行结算中使用。这样可以避免将未知的低价和高价时刻提前用于储能套利。')+
eq(r'\hat p_{d,t}=\frac17\sum_{i=1}^{7}p_{d-i,t},\qquad R^p_{j,t}=p_{j,t}-\hat p_{j,t}.')+
eq(r'p_{d,t}^{s}=\max\{0.001,\hat p_{d,t}+R^p_{d-s,t}\},\qquad s=1,\ldots,30.')+
para('0.001元/kWh是价格情景的正值保护阈值，仅作用于历史残差叠加产生的预测情景，不修改附件4中的任何实测价格。净负载残差和价格残差使用同一历史日期，保留二者在经验样本中的相关关系。')+
fig('price','日内价格分布与日前日均价格预测。区间带反映不同日期同一时刻价格的波动。')+
para('2月至12月的价格预测RMSE为0.1053元/kWh。按全年最大值除以最小值得到的比值，不能代表同一天能够实现的套利机会，因为两个极值可能位于不同日期，且受到SOC和充放电功率限制。储能动作必须按可见价格分布决定，不能按事后极值拼接。'))

#22
page('6.4.2 价格加权分位与风险模型',para('将问题2和问题3的目标中确定电价替换为联合情景电价，取情景费用均值。对于不调整情形，目标为')+
eq(r'\min Z_{4-2}=\frac1M\sum_s\sum_t p_t^s\left(g_t+5u_t^s\right).')+
para('对于滚动调整，原计划$g_t$固定，剩余时域目标变为')+
eq(r'\min Z_{4-3}^{\tau}=\frac1M\sum_s\sum_{t\in\mathcal T_\tau}p_t^s\left(a_t+\frac12v_t+5u_t^s\right).')+
para('若电价随机且与净需求相关，不能直接沿用无权重0.8分位。固定充放电后，日前最优性的边际条件为')+
eq(r'\mathbb E\!\left[p_t\mathbf1\{X_t>g_t^*\}\right]=\frac15\mathbb E[p_t].')+
para('因此应使用价格加权经验分布。只有电价为已知常数，或与需求独立并满足相应条件时，电价才能约去，退化为普通0.8分位。滚动调整的0.7和0.9规则也相应成为价格加权分位。程序直接求解联合情景LP，避免以错误的无权重分位覆盖其解。')+
sub('6.4.3 CVaR扩展')+
para(r'令$C^s$为一天在第$s$条联合情景下的总费用，取置信水平$\alpha=0.95$。利用Rockafellar与Uryasev的凸表示\cite{cvar}，有')+
eq(r'\operatorname{CVaR}_{\alpha}(C)=\min_{\zeta}\left\{\zeta+\frac1{(1-\alpha)M}\sum_s\xi_s\right\},\quad \xi_s\ge C^s-\zeta,\quad \xi_s\ge0.')+
eq(r'\min\ (1-\lambda)\frac1M\sum_s C^s+\lambda\left(\zeta+\frac1{(1-\alpha)M}\sum_s\xi_s\right).')+
para(r'其中$\zeta$为自由辅助变量，避免与充放电效率符号混淆。主交付采用$\lambda=0$，其余权重只在四个指定日期作敏感性分析，不把这些日期的最小费用权重描述成经过独立样本外验证的全年最优参数。'))

#23-28
for n,prefix in [('q4_2','6.4.4'),('q4_3','6.4.5')]:
    rolling=n=='q4_3'
    page(prefix+' '+NAMES[n]+'指定日期的购电结果',para('本组结果使用附件4实测价格进行最终结算，决策阶段采用历史价格预测与联合残差情景。六个指定时段为0:00形成的计划量，全天总费用包含所有实际发生的费用项目。')+purchase_tables(n)+day_summary(n)+
      para('这些数值由波动电价下重新优化得到，不是将固定价格结果简单乘以新电价。电价情景会改变储能充放电顺序及各需求情景的成本权重，从而同时改变申报量和实际紧急购电量。'+('最终生效申报量另存于调整购电量工作表。' if rolling else '本方案没有日内计划调整，生效申报量始终等于0:00计划。')))
    page(prefix+'（续）'+NAMES[n]+'储能结果',para('以下保留题目表2的配对格式。所有数值均来自本方案的实际执行轨迹，单位为kWh。相同储能设备和首尾政策保证不同价格方案之间具有可比的设备条件。')+battery_tables(n)+
      para('波动价格下的储能策略需要权衡未来电价分布与供电风险。某一时段的实际价格很低，不能保证该时段事先已经安排充电；只有价格预测或联合情景给出了相应信号，调度器才会在决策时体现这一机会。')+
      para('4小时时间段内的充电与放电分别累加，SOC边界则在每个10分钟时段上检查。若只检查表格中的0:00和24:00储电量，仍可能遗漏日内越限，因此附带文件保留完整SOC轨迹和逐时段约束核查结果。'))
    page(prefix+'（续）'+NAMES[n]+'紧急购电结果',para('下表列出四个指定日期的全部非零紧急购电连续区间。全年文件保留其余330天的同类结果，未将日期省略行当作无紧急购电。')+emergency_table(n)+
      table(NAMES[n]+'指定日的紧急费用与总费用',['日期','紧急电量/kWh','紧急费用/元','总费用/元'],[[date,num(F[n].query('date==@date').emergency.sum()),num(F[n].query('date==@date').emergency_cost.sum()),num(F[n].query('date==@date').total_cost.sum())] for date in DATES],size='9.5')+
      para('紧急费用使用每个10分钟时段的实际价格乘以5，再与该时段紧急电量相乘求和。将连续区间内的变化价格按日均价替代会破坏题目规定的结算方式，也会改变日间比较结论。')+
      para(r'发生紧急购电说明计划与储能供给存在偏差，并不表示模型允许停电。紧急电量作为补偿变量参与最终能量守恒，结果中的负载满足率在本题无限紧急购电假设下为100\%。可靠供电来自补偿机制，较小的紧急量则表示事前计划更贴合实际。'))

#29
riskrows=[]
for lam in [0,.25,.5,.75,1.]:
    ff=F['q4_2'].query('date in @DATES') if lam==0 else pd.read_csv(O/f'q4_risk_{lam}_dispatch.csv')
    riskrows.append([str(lam),num(ff.total_cost.sum()),num(ff.plan.sum()),num(ff.emergency.sum()),num(ff.emergency_cost.sum())])
page('6.4.6 风险敏感性与波动价格的影响',table('问题四-2在指定四日的风险权重实验',[r'$\lambda$','四日费用/元','计划量/kWh','紧急量/kWh','紧急费/元'],riskrows,size='9.5')+
fig('risk','风险权重变化对指定四日实际费用和紧急电量的影响。各点均重新优化。')+
para('提高风险权重使优化更重视高费用情景，通常增加提前申报电量，并减少部分高价紧急补偿。在四日实际结算中，总费用随权重上升而增加，说明为降低情景尾部风险付出了一定备量成本。实际紧急量在最高权重处也未严格单调下降，风险目标的改善不等于每项实际指标同步改善。')+
para(r'此实验只有四个指定日期，不能据此推断全年最优风险权重，更不能将已实现四日损失的变化直接当作情景CVaR变化。要把风险权重用于长期运营，应在训练期确定权重，再用未参与选择的未来时间段检验。本次主交付保留风险中性的$\lambda=0$。')+
para('另以四日全天实测价格在0:00已知的条件重算问题四-2，费用为193006.09元。该结果仅为价格信息条件的对照，不作为实时可执行主策略，也不被称为实际年度成本的严格下界。已知价格仍不等于已知未来负载和光伏。')+
para('第四问两套主方案的334天总费用分别为15398983.56元和15437919.30元。滚动方案紧急量较少，但总费用略高，表明官方预报误差、调整费与正常申报费的增加抵消了紧急费节约。'))

#30
vr=[]
for n in NAMES:
    d=A[n];vr.append([NAMES[n],f"{d['max_balance_error']:.1e}",f"{d['max_soc_error']:.1e}",d['simultaneous_slots'],f"{d['max_lp_dual_gap']:.1e}"])
page('七、结果检验与可复现性',sub('7.1 逐时段独立核验')+
para('结果检验从已经导出的执行数据重新计算，不直接复用求解器内部的松弛变量。对四套主方案逐日逐时段检验供需平衡、SOC等式、上下限、充放电功率、互斥性、日边界和费用。供需与储能残差分别定义为')+
eq(r'\varepsilon^N_{d,t}=a_{d,t}+e_{d,t}+b_{d,t}-c_{d,t}-r_{d,t}-N_{d,t},')+
eq(r'\varepsilon^S_{d,t}=S_{d,t}-S_{d,t-1}-0.9c_{d,t}+b_{d,t}/0.9.')+
table('四套主方案的数值核验',['方案','平衡误差/kWh','SOC误差/kWh','同时充放电','LP间隙/元'],vr,size='9.5')+
para('四套主方案各包含48096个时段，未出现同时充放电；储电量在1200至10800 kWh范围内，充放电量不超过833.333333 kWh/时段；每天24:00回到6000 kWh。出现$10^{-12}$量级的小数误差属于浮点计算容差，不代表物理越界。')+
sub('7.2 费用分解与输出核对')+
eq(r'Z=Z_{\rm plan}-Z_{\rm refund}+Z_{\rm down}+Z_{\rm up}+Z_{\rm em}.')+
para(r'其中原计划费为$\sum pg$，取消退款为$\sum p(g-a)^+$，调减违约费为退款的一半，调增费为$\sum1.5p(a-g)^+$，紧急费为$\sum5pe$。独立公式$\sum[\Phi(g,a;p)+5pe]$与逐项费用相加的最大差异小于$10^{-9}$元。')+
para('Excel保留未舍入的数值，显示两位小数。正文表格从同一执行CSV生成；日合计由全部144时段求和，紧急连续段合计再与逐日总量比较。日期从2025年2月1日至12月31日连续，共334天。输入附件、模型源码、图表源码、数值结果、校验记录及LaTeX源文件共同构成复现材料。')+
sub('7.3 信息时点核验')+
para('日前残差索引严格小于决策日；预报以发布时刻划分可用范围；实时价格仅用于结算。判断程序有无未来信息，应核查索引与目标系数来源，不能只依靠“守恒检查通过”。守恒检验验证物理可行性，原对偶间隙验证子问题求解精度，两者都不能替代信息时点检查。'))

#31
page('八、模型评价与结论',sub('8.1 模型优点')+
para('首先，四问采用统一的电量计量和SOC递推，日内、跨阶段及日末边界能够直接对应。购电、紧急补偿和弃用电量分工明确，可以用独立公式验证每个时段的物理可行性。其次，采用稀疏线性规划求解，情景补偿、绝对值调整费和CVaR均保持线性结构，便于比较、审计与复现。')+
para('再次，模型区分了预测来源、预报更新时间和电价信息三类因素。控制变量实验表明，日内更新在相同官方预报来源下确有经济价值；在不同来源之间比较时，则必须同时考虑预测精度。价格与净需求联合采样避免了简单套用无权重分位的错误。')+
sub('8.2 模型局限与改进方向')+
para('第一，每日末端6000 kWh限制了跨日储能转移机会。该政策是题目可行域的保守子集，因此本报告的年度成本不是所有允许跨日策略中的最小成本。可进一步采用多日滚动时域与终端价值函数，但必须继续保证历史状态连续，并避免每日免费重置电量。')+
para('第二，光伏整点值近似为小时平均功率，采用阶梯法能够保证电量一致，但无法恢复小时内部波动。可用仅基于历史数据的形状法改进，并在相同评估区间比较。第三，负载预测没有根据当日已发生负载进行更新，这限制了滚动策略应对日内负载偏移的能力。')+
para('第四，滚动子问题未建立完整多阶段情景树，因而不能把子问题的全局最优扩展成全年度随机控制的全局最优。30条残差路径对极端天气和价格尾部的表示也有限。CVaR实验仅作指定日敏感性分析，尚不足以支持全年风险权重的统计结论。')+
para('第五，结果依赖取消电量退费再支付半价违约费的结算解释。如果原计划电费不退，需重新求解相应合同模型；不能只在现有最优策略的费用末尾加一项就称为另一合同的最优解。模型还忽略了电池寿命成本、线路容量以及外网紧急购电上限。')+
sub('8.3 主要结论')+
para(r'问题1通过光伏消纳与价格时序优化将单日购电费降低26.90\%。问题2在固定电价和历史预测条件下实现可行日前计划，334天费用为1456.54万元。问题3利用四次官方预报相对仅00时官方预报节约33.01万元，证明日内更新值得引入；但其全年费用并未低于问题2，说明预报质量与更新频率应分别评价。')+
para('波动电价下，两套可执行主策略的费用分别为1539.90万元与1543.79万元。风险扩展展示了增加计划备量、减少部分紧急购电与总成本之间的权衡。题目要求的单日策略、四个指定日表格、年度策略及五份结果工作簿均已给出，所有主结果均由修正模型真实计算和检验得到。'))

#32
page('参考文献与附录',r'''\begingroup\small
\renewcommand{\refname}{}\vspace{-12mm}
\begin{thebibliography}{9}
\bibitem{problem} 2026年高教社杯全国大学生数学建模竞赛. C题：微网与外部电网电力调控策略及附件1--5[Z]. 用户提供，2026.
\bibitem{project} 项目资料. C题基础章节、解题思路与开发路线图、预处理数据、问题一至问题四求解代码和结果包[Z]. 用户提供，2026.
\bibitem{cvar} ROCKAFELLAR R T, URYASEV S. Optimization of conditional value-at-risk[J]. Journal of Risk, 2000, 2(3): 21--42. 作者文献目录：\url{https://uryasev.github.io/publications/}.
\bibitem{highs} HUANGFU Q, HALL J A J. Parallelizing the dual revised simplex method[J]. Mathematical Programming Computation, 2018, 10: 119--142. DOI: 10.1007/s12532-017-0130-5.
\bibitem{scipy} SciPy Developers. scipy.optimize.linprog, method=highs[EB/OL]. \url{https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html}. 访问日期：2026-09-12.
\end{thebibliography}\endgroup
'''+sub('附录A　复现步骤与文件对应')+
table('主要文件及用途',['文件或目录','内容'],[
['data/','统一时间口径的实测、单日和小时预报CSV'],['code/Q1-Q4_Q1-Q4_solve.py','四问LP、滚动执行、风险实验与物理核验'],[r'code/build\_assets.py','图表及Excel中间数据生成'],[r'code/export\_workbooks.mjs','五份正式Excel结果导出'],[r'code/build\_report.py','正文、公式与表格的LaTeX源文件生成'],['code/Q1-Q4_audit.py','独立终审：原始附件、守恒/SOC/费用、五份Excel反向核对'],['results/','逐时段、逐日结果和五份Excel文件'],['report/report.tex','完整可编辑论文LaTeX源文件'],['report/figures/','图表PDF、SVG、PNG'],['report/fonts/','Noto Serif/Sans CJK字体及开放许可'],[r'source\_inputs/、original\_work/','原始附件、模板及已有项目材料']],spec='ll',size='9.5')+
para(r'在附带文件夹根目录运行code/Q1-Q4_Q1-Q4_solve.py可重建计算结果，随后运行build\_assets.py和build\_report.py生成图表与LaTeX。进入report目录后，连续两次执行xelatex编译。完整环境与Excel导出方法见README。所有图表均由数据和代码生成，公式采用LaTeX数学环境排版。')+
para('原项目文件用于追踪已有工作，不将其中的旧数值与本次正式输出混合使用。旧稿中被修正的关键问题包括弃用电量符号、滚动调整费用未进入联合LP、全年形状信息和当天实测价格被提前使用，以及输出模板时间标签错位。'))

#33
page('附录B　核心算法与结果口径',para('以下展示滚动策略的核心执行逻辑。完整可运行实现位于code/Q1-Q4_Q1-Q4_solve.py，包括稀疏矩阵构造、边界处理、场景价格权重、原对偶间隙和数值核验。伪代码中的实际数据读取严格位于执行阶段。')+r'''
\begin{lstlisting}[language=Python]
for day in evaluation_days:
    initial_soc = 6000.0
    original_plan = None
    for stage in release_times:
        history = days_before(day, length=30)
        net_scenarios = forecast(day, stage) + residuals(history, stage)
        price_scenarios = causal_price_scenarios(day, history)
        # The LP includes adjustment cost jointly with battery dispatch.
        q, charge, discharge, soc = solve_joint_lp(
            net_scenarios, price_scenarios,
            start_soc=initial_soc, end_soc=6000.0,
            original_plan=original_plan)
        if original_plan is None:
            original_plan = q.copy()
        # Execute only until the next release. Future values remain unseen.
        for t in current_execution_window(stage):
            net = actual_load(day, t) - actual_pv(day, t)
            emergency = max(0, net + charge[t] - discharge[t] - q[t])
            curtail = max(0, q[t] + discharge[t] - charge[t] - net)
            p = actual_transaction_price(day, t)
            g = original_plan[t]
            cost = p * (min(g, q[t]) + 0.5 * max(g-q[t], 0)
                    + 1.5 * max(q[t]-g, 0) + 5 * emergency)
            record_dispatch(t, q[t], charge[t], discharge[t],
                            soc[t], emergency, curtail, cost)
        initial_soc = last_executed_soc()
    validate_all_slots(day)
\end{lstlisting}
'''+sub('附录C　Excel填写口径')+
para('计划购电量工作表给出0:00计划$g$、全天计划量和原计划费用。调整购电量工作表给出生效总量$a$、全天生效申报量和包含紧急购电的总费用。问题2的总费用可由计划表中的计划费与紧急购电清单按交易价格重算，也可直接查询逐日CSV。')+
para('储能表按6个4小时区间填写，并保留日首尾电量；紧急表按相邻正值时段合并。内部保存完整精度，显示保留两位小数。接近零的数值只属于浮点误差，正式物理约束采用$10^{-6}$ kWh容差。问题3与问题四-3的调整表包含已执行窗口拼接后的最终量，不包含尚未执行时域的重复试算方案。'))

(R/'report.tex').write_text(preamble+'\n'.join(chunks)+'\n\\end{document}\n')
print('Authored sections/pages:',len(chunks))
