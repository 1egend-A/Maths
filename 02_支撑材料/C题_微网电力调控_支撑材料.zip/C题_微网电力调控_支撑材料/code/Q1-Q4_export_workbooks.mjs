import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.resolve(process.argv[2]||'.');
const data=JSON.parse(await fs.readFile(path.join(root,'results/workbook_payload.json'),'utf8'));
for (const [name,sheets] of Object.entries(data)) {
  const wb=Workbook.create();
  for (const [sheetName,rows] of Object.entries(sheets)) {
    const s=wb.worksheets.add(sheetName);const nc=rows[0].length,nr=rows.length;
    if(name!=='result1') for(let i=1;i<nr;i++) if(typeof rows[i][0]==='string' && /^2025-/.test(rows[i][0]))rows[i][0]=new Date(rows[i][0]+'T00:00:00Z');
    s.getRangeByIndexes(0,0,nr,nc).values=rows;
    const all=s.getRangeByIndexes(0,0,nr,nc);
    all.format.font={name:'Noto Serif CJK SC',size:10};all.format.rowHeight=22;
    all.format.verticalAlignment='center';
    all.format.columnWidth=18;all.setNumberFormat('0.00');
    s.getRangeByIndexes(0,0,1,nc).format.font={name:'Noto Serif CJK SC',bold:true,size:10};
    s.getRangeByIndexes(0,0,1,nc).format.fill='#E7ECF1';
    s.getRangeByIndexes(0,0,1,nc).format.wrapText=true;
    s.getRangeByIndexes(0,0,1,nc).format.rowHeight=38;
    s.getRangeByIndexes(0,0,nr,1).format.columnWidth=name==='result1'?21:15;
    if(name!=='result1')s.getRangeByIndexes(1,0,nr-1,1).setNumberFormat('yyyy-mm-dd');
    if(nc>100){
      s.getRangeByIndexes(0,nc-2,nr,2).format.columnWidth=27;
      // Native SUM remains editable; dispatch itself is an optimization output.
      s.getRangeByIndexes(1,nc-2,nr-1,1).formulas=Array.from({length:nr-1},(_,i)=>[`=SUM(B${i+2}:EO${i+2})`]);
    }
    if(sheetName==='紧急购电量')s.getRangeByIndexes(0,1,nr,1).format.columnWidth=24;
    s.showGridLines=false;s.freezePanes.freezeRows(1);
  }
  wb.recalculate();
  console.log(name,(await wb.inspect({kind:'table',range:'计划购电量!A1:D4',include:'values,formulas',tableMaxRows:4,tableMaxCols:4})).ndjson);
  console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!',options:{useRegex:true,maxResults:5}})).ndjson);
  for (const [sheetName,rows] of Object.entries(sheets)) {
    const range=rows[0].length>100?'A1:F7':(rows[0].length===6?'A1:F8':(rows[0].length===5?'A1:E7':(rows[0].length===3?'A1:C9':'A1:B9')));
    const preview=await wb.render({sheetName,range,scale:1.5,format:'png'});
    await fs.writeFile(path.join(root,'checks',`${name}_${sheetName}.png`),new Uint8Array(await preview.arrayBuffer()));
  }
  await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(root,'results',name+'.xlsx'));
  console.log('EXPORTED',name);
}
