"""Microgrid C: causal scenarios, joint rolling settlement LP, reproducible outputs.
Run from this directory's parent: python code/solve.py
All powers in kW; internal and exported dispatch in kWh per 10-minute slot.
"""
from pathlib import Path
import json, time, sys
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy import sparse
from functools import lru_cache

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
DT=1/6; ETA=.9; PM=5000*DT; LO=1200.; HI=10800.; S0=6000.

def load_data():
    a=pd.read_csv(DATA/'actual_2025_10min.csv'); b=pd.read_csv(DATA/'attachment1_10min.csv')
    fc=pd.read_csv(DATA/'forecast_hourly.csv')
    L=a.load_kW.to_numpy().reshape(365,144)*DT
    V=a.pv_actual_kW.to_numpy().reshape(365,144)*DT
    P=a.price_yuan_per_kWh.to_numpy().reshape(365,144)
    F=fc.pv_forecast_kW.to_numpy().reshape(365,4,24)
    return a,b,L,V,P,F

def forecasts(L,V,P,F,b,shape=False):
    lh=np.zeros_like(L);vh=np.zeros_like(V);ph=np.zeros_like(P)
    lh[0]=b.load_kW.to_numpy()*DT; vh[0]=b.pv_forecast_kW.to_numpy()*DT
    ph[0]=b.price_yuan_per_kWh.to_numpy()
    for d in range(1,365):
        ix=[d-7*i for i in range(1,5) if d-7*i>=0]
        lh[d]=.5*L[ix[0]]+.5*L[ix].mean(0) if ix else L[d-1]
        vh[d]=V[max(0,d-7):d].mean(0);ph[d]=P[max(0,d-7):d].mean(0)
    # Shape, when requested, is frozen using January only, never annual values.
    weights=V[:31].mean(0).reshape(24,6)
    den=weights.sum(1,keepdims=True)
    weights=np.divide(6*weights,den,out=np.ones_like(weights),where=den>0)
    nh=np.full((365,4,144),np.nan)
    for j,hour in enumerate([0,6,12,18]):
        vals=np.repeat(F[:,j,:24-hour],6,axis=1)*DT
        if shape: vals*=weights[hour:].reshape(1,-1)
        nh[:,j,hour*6:]=lh[:,hour*6:]-vals
    return lh,vh,ph,nh

@lru_cache(None)
def matrices(h,s,adjust):
    # q,c,b,S,u_s,[v = |q-G|]. Each u block is one whole scenario path.
    n=4*h+s*h+(h if adjust else 0)
    row=np.arange(s*h); t=np.tile(np.arange(h),s)
    A=sparse.coo_matrix((np.tile([-1.,1.,-1.,-1.],(s*h,1)).T.ravel(),
      (np.tile(row,4),np.r_[t,h+t,2*h+t,4*h+row])),shape=(s*h,n)).tocsr()
    rr=np.arange(h)
    eq=sparse.coo_matrix((np.r_[np.ones(h),-np.ones(h-1),-ETA*np.ones(h),np.ones(h)/ETA],
      (np.r_[rr,rr[1:],rr,rr],np.r_[3*h+rr,3*h+rr[:-1],h+rr,2*h+rr])),shape=(h,n)).tocsr()
    bounds=np.c_[np.zeros(n),np.full(n,np.inf)]
    bounds[h:3*h,1]=PM;bounds[3*h:4*h,0]=LO;bounds[3*h:4*h,1]=HI
    bounds[4*h-1]=S0
    if adjust:
        v=4*h+s*h+rr
        B=sparse.coo_matrix((np.r_[np.ones(h),-np.ones(h),-np.ones(h),-np.ones(h)],
          (np.r_[rr,rr,h+rr,h+rr],np.r_[rr,v,rr,v])),shape=(2*h,n)).tocsr()
        A=sparse.vstack([A,B],format='csr')
    return A,eq,bounds

def lp(Ns,ps,start=S0,G=None,risk=0.,capacity=None):
    """Ns, ps: S x H; ps is scenario price, correlated with net load.
    G=None: day-ahead; otherwise original midnight baseline for settlement.
    """
    s,h=Ns.shape;adj=G is not None
    A,E,bounds=matrices(h,s,adj);bounds=bounds.copy();n=len(bounds)
    if capacity is not None:
        bounds[3*h:4*h,0]=capacity[0];bounds[3*h:4*h,1]=capacity[1];bounds[4*h-1]=S0
    meanp=ps.mean(0);f=np.zeros(n);f[:h]=meanp
    f[4*h:4*h+s*h]=(5*ps/s).ravel()
    if adj:f[4*h+s*h:]=.5*meanp
    rhs=-Ns.ravel()
    if adj:rhs=np.r_[rhs,G,-G]
    erhs=np.r_[start,np.zeros(h-1)]
    if risk:
        # Full path costs in the same historical price / net-demand scenarios.
        cost=sparse.lil_matrix((s,n))
        for k in range(s):
            cost[k,:h]=ps[k];cost[k,4*h+k*h:4*h+(k+1)*h]=5*ps[k]
            if adj:cost[k,4*h+s*h:]=.5*ps[k]
        Z=sparse.hstack([cost.tocsr(),-np.ones((s,1)),-sparse.eye(s)],format='csr')
        A=sparse.vstack([sparse.hstack([A,sparse.csr_matrix((A.shape[0],s+1))]),Z],format='csr')
        E=sparse.hstack([E,sparse.csr_matrix((h,s+1))],format='csr')
        bounds=np.vstack([bounds,[-np.inf,np.inf],np.c_[np.zeros(s),np.full(s,np.inf)]])
        rhs=np.r_[rhs,np.zeros(s)]
        f=np.r_[(1-risk)*f,risk,np.full(s,risk/(.05*s))]
    sol=linprog(f,A_ub=A,b_ub=rhs,A_eq=E,b_eq=erhs,bounds=bounds,method='highs')
    if not sol.success:raise RuntimeError(sol.message)
    x=sol.x; q=x[:h].copy();c=x[h:2*h].copy();b=x[2*h:3*h].copy();soc=x[3*h:4*h]
    # Eliminate cost-neutral simultaneous charge/discharge while preserving SOC.
    cyc=np.minimum(c,b/ETA**2);c-=cyc;b-=ETA**2*cyc
    # Fix the lower optimal quantile for deterministic common price, midnight only.
    if not adj and not risk and np.max(np.abs(ps-ps[0]))<1e-12:
        q=np.maximum(0,np.sort(Ns+c-b,axis=0)[int(np.ceil(.8*s))-1])
    dual=float(rhs@sol.ineqlin.marginals+erhs@sol.eqlin.marginals+
        np.where(np.isfinite(bounds[:,0]),bounds[:,0],0)@sol.lower.marginals+
        np.where(np.isfinite(bounds[:,1]),bounds[:,1],0)@sol.upper.marginals)
    return q,c,b,soc,abs(sol.fun-dual)

def run(name,L,V,P,nh,ph,stages=(0,),volatile=False,risk=0.,days=None,oracle_price=False):
    nact=L-V;days=range(31,365) if days is None else days
    cols=['date','slot','plan','adjusted','charge','discharge','soc','emergency','curtail',
          'price','plan_cost','refund','down_penalty','up_cost','emergency_cost','total_cost']
    records=[];diag=[];tic=time.time()
    for d in days:
        G=None;start=S0
        for j,st in enumerate(stages):
            stop=stages[j+1] if j+1<len(stages) else 144
            pool=np.arange(max(0,d-30),d);stage=st//36 if nh.ndim==3 else 0
            pred=nh[d,stage] if nh.ndim==3 else nh[d]
            hist=nh[pool,stage] if nh.ndim==3 else nh[pool]
            Ns=pred[None,st:]+(nact[pool,st:]-hist[:,st:])
            if volatile:
                ps=np.maximum(.001,ph[d,st:]+P[pool,st:]-ph[pool,st:])
                if oracle_price:ps=np.broadcast_to(P[d,st:],Ns.shape)
            else:ps=np.broadcast_to(P[d,st:],Ns.shape)
            q,c,b,soc,gap=lp(Ns,ps,start,G=None if st==0 else G[st:],risk=risk)
            if G is None:G=q.copy()
            end=stop-st;g=G[st:stop];q=q[:end];c=c[:end];b=b[:end];soc=soc[:end]
            e=np.maximum(0,nact[d,st:stop]+c-b-q);curt=np.maximum(0,q+b-c-nact[d,st:stop])
            price=P[d,st:stop];down=np.maximum(0,g-q);up=np.maximum(0,q-g)
            plan=price*g;refund=price*down;pen=.5*price*down;extra=1.5*price*up;em=5*price*e
            total=plan-refund+pen+extra+em
            date=str(pd.Timestamp('2025-01-01')+pd.Timedelta(days=int(d)))[:10]
            for k in range(end):
                records.append([date,st+k+1,g[k],q[k],c[k],b[k],soc[k],e[k],curt[k],price[k],
                  plan[k],refund[k],pen[k],extra[k],em[k],total[k]])
            diag.append(dict(date=date,stage=st//6,history_last_day=int(d-1),dual_gap=gap))
            start=soc[-1]
        if (d-30)%50==0:print(name,d+1,'/365',round(time.time()-tic,1),'s',flush=True)
    frame=pd.DataFrame(records,columns=cols);frame.to_csv(OUT/f'{name}_dispatch.csv',index=False)
    daily=frame.groupby('date').sum(numeric_only=True)
    daily['soc']=frame.groupby('date').soc.last();daily.to_csv(OUT/f'{name}_daily.csv')
    pd.DataFrame(diag).to_csv(OUT/f'{name}_decision_log.csv',index=False)
    audit=validate(frame);audit['max_lp_dual_gap']=max(x['dual_gap'] for x in diag)
    audit['elapsed_seconds']=time.time()-tic
    (OUT/f'{name}_audit.json').write_text(json.dumps(audit,indent=2))
    print(name, json.dumps(audit),flush=True)
    return frame

def validate(f):
    a,b,L,V,P,F=load_data();ix=(pd.to_datetime(f.date)-pd.Timestamp('2025-01-01')).dt.days.to_numpy()
    t=f.slot.to_numpy()-1;net=(L-V)[ix,t]
    prev=f.soc.shift().to_numpy();prev[t==0]=S0
    balance=f.adjusted+f.emergency+f.discharge-f.charge-f.curtail-net
    soc=f.soc-prev-ETA*f.charge+f.discharge/ETA
    cost=f.price*(np.minimum(f.plan,f.adjusted)+.5*np.maximum(0,f.plan-f.adjusted)+
      1.5*np.maximum(0,f.adjusted-f.plan)+5*f.emergency)
    out=dict(n_days=int(f.date.nunique()),n_slots=len(f),max_balance_error=float(np.abs(balance).max()),
      max_soc_error=float(np.abs(soc).max()),min_soc=float(f.soc.min()),max_soc=float(f.soc.max()),
      max_charge=float(f.charge.max()),max_discharge=float(f.discharge.max()),
      simultaneous_slots=int(((f.charge>1e-6)&(f.discharge>1e-6)).sum()),
      max_terminal_error=float(np.abs(f.groupby('date').soc.last()-S0).max()),
      max_cost_error=float(np.abs(cost-f.total_cost).max()),total_cost=float(f.total_cost.sum()),
      total_plan=float(f.plan.sum()),total_adjusted=float(f.adjusted.sum()),total_emergency=float(f.emergency.sum()),
      total_emergency_cost=float(f.emergency_cost.sum()),total_curtail=float(f.curtail.sum()))
    assert out['max_balance_error']<1e-6 and out['max_soc_error']<1e-6
    assert out['min_soc']>=LO-1e-6 and out['max_soc']<=HI+1e-6
    assert out['simultaneous_slots']==0 and out['max_terminal_error']<1e-6
    assert out['max_charge']<=PM+1e-6 and out['max_discharge']<=PM+1e-6
    assert out['max_cost_error']<1e-6
    return out

def q1(b):
    net=(b.load_kW-b.pv_forecast_kW).to_numpy()*DT;p=b.price_yuan_per_kWh.to_numpy()
    # deterministic LP is equivalent to expensive recourse as optimal e is zero.
    q,c,dis,soc,gap=lp(net[None,:],p[None,:])
    curt=q+dis-c-net
    df=pd.DataFrame(dict(slot=np.arange(1,145),plan=q,charge=c,discharge=dis,soc=soc,curtail=curt,price=p,total_cost=p*q))
    df.to_csv(OUT/'q1_dispatch.csv',index=False)
    summary=dict(cost=float(p@q),purchase=float(q.sum()),baseline_cost=float(p@np.maximum(0,net)),
      baseline_purchase=float(np.maximum(0,net).sum()),dual_gap=gap,
      max_balance_error=float(np.max(np.abs(q+dis-c-curt-net))),max_soc_error=float(np.max(np.abs(soc-np.r_[S0,soc[:-1]]-ETA*c+dis/ETA))))
    (OUT/'q1_audit.json').write_text(json.dumps(summary,indent=2));print('q1',summary,flush=True)

def main():
    a,b,L,V,P,F=load_data();lh,vh,ph,nh=forecasts(L,V,P,F,b)
    if '--force' in sys.argv:
        for f in OUT.glob('*_audit.json'):
            if f.name not in ['data_audit.json','final_independent_audit.json']:f.unlink()
    fixed=np.broadcast_to(b.price_yuan_per_kWh.to_numpy(),P.shape)
    np.savez_compressed(OUT/'forecasts.npz',load=lh,pv=vh,price=ph,net4=nh)
    for tag,pred in [('q2',lh-vh),('q3',nh[:,0])]:
        net=(L-V)[:31];g=np.maximum(0,pred[:31]);e=np.maximum(0,net-g);r=np.maximum(0,g-net)
        pd.DataFrame({'date':np.repeat(pd.date_range('2025-01-01',periods=31).astype(str),144),
          'slot':np.tile(np.arange(1,145),31),'plan':g.ravel(),'emergency':e.ravel(),
          'curtail':r.ravel(),'charge':0.,'discharge':0.,'soc':S0}).to_csv(OUT/f'{tag}_january_initialization.csv',index=False)
    q1(b)
    tasks=[('q2',fixed,lh-vh,(0,),False),('q3',fixed,nh,(0,36,72,108),False),
      ('q4_2',P,lh-vh,(0,),True),('q4_3',P,nh,(0,36,72,108),True)]
    for name,prices,pred,stages,vol in tasks:
        if not (OUT/f'{name}_audit.json').exists():run(name,L,V,prices,pred,ph,stages,vol)
    # Controlled ablation: same source, same solver, change forecast release use only.
    for name,stages in [('q3_00',(0,)),('q3_0012',(0,72)),('q3_0006',(0,36))]:
        if not (OUT/f'{name}_audit.json').exists():run(name,L,V,fixed,nh,ph,stages)
    # Additional price-information and risk comparisons on the four required days.
    special=[(pd.Timestamp(x)-pd.Timestamp('2025-01-01')).days for x in ['2025-03-20','2025-06-21','2025-09-23','2025-12-21']]
    for lam in [.25,.5,.75,1.]:
        name=f'q4_risk_{lam}'
        if not (OUT/f'{name}_audit.json').exists():run(name,L,V,P,lh-vh,ph,volatile=True,risk=lam,days=special)
    if not (OUT/'q4_price_known_audit.json').exists():run('q4_price_known',L,V,P,lh-vh,ph,volatile=True,days=special,oracle_price=True)

if __name__=='__main__':main()
